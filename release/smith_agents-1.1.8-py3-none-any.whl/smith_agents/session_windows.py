"""Resolve session owners and retain bounded, verified host window targets."""
from collections import OrderedDict
import re
import threading


# Providers whose sessions live inside a host this widget does not own: their
# own app ends them, their readings come from their own parser, and a row is
# trusted only while its process is the one that was scanned.
HOSTED_PROVIDERS = ("codex", "hermes", "deepseek")


def window_agent(agent, agents):
    """A spawned subagent uses its ancestor's window, not a separate chat."""
    seen = set()
    while agent and agent.get('sub'):
        key = (agent.get('provider'), agent.get('id'))
        if key in seen:
            return None
        seen.add(key)
        agent = next((parent for parent in agents
                      if parent.get('id') == agent.get('parent')
                      and parent.get('provider') == agent.get('provider')), None)
    return agent


def title_matches_project(title, leaf):
    """Avoid matching project 'app' inside an unrelated project 'myapp'."""
    return bool(leaf and re.search(r'(?<![\w.-])' + re.escape(leaf) + r'(?![\w.-])',
                                  title, re.IGNORECASE))


class WindowTargets:
    def __init__(self, limit=128):
        self.limit = limit
        self.lock = threading.Lock()
        self.targets = OrderedDict()

    @staticmethod
    def key(agent):
        return (agent.get('id'), agent.get('pid'), agent.get('started_at'))

    def remember(self, agent, target):
        key = self.key(agent)
        with self.lock:
            self.targets[key] = target
            self.targets.move_to_end(key)
            while len(self.targets) > self.limit:
                self.targets.popitem(last=False)

    def get(self, agent):
        with self.lock:
            return self.targets.get(self.key(agent))

    def discard(self, agent):
        with self.lock:
            self.targets.pop(self.key(agent), None)
